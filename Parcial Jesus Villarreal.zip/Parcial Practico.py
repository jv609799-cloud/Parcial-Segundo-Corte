# EJERCICIO 1
print("----- EJERCICIO 1 -----")

numeros = []

for i in range(5):
    n = int(input("Ingrese un número: "))
    numeros.append(n)
    
print("Número mayor:", max(numeros))
print("Número menor:", min(numeros))
print("Promedio:", sum(numeros)/len(numeros))


# EJERCICIO 2
print("\n----- EJERCICIO 2 -----")

def es_primo(numero):
    if numero <= 1:
        return False
    for i in range(2, numero):
        if numero % i == 0:
            return False
    return True

print(es_primo(7))


# EJERCICIO 3
print("\n----- EJERCICIO 3 -----")

for i in range(1, 51):
    if i % 3 == 0 and i % 5 == 0:
        print("FizzBuzz")
    elif i % 3 == 0:
        print("Fizz")
    elif i % 5 == 0:
        print("Buzz")
    else:
        print(i)


# EJERCICIO 4
print("\n----- EJERCICIO 4 -----")

numeros = [3, 7, 12, 18, 21, 30]
pares = []

for n in numeros:
    if n % 2 == 0:
        pares.append(n)

print(pares)


# EJERCICIO 5
print("\n----- EJERCICIO 5 -----")

def invertir_palabra(palabra):
    return palabra[::-1]

print(invertir_palabra("python"))


# EJERCICIO 6
print("\n----- EJERCICIO 6 -----")

palabra = input("Ingrese una palabra: ")
letra = input("Ingrese una letra: ")

contador = palabra.count(letra)

print("La letra aparece", contador, "veces")


# EJERCICIO 7
print("\n----- EJERCICIO 7 -----")

estudiante = {
    "nombre": "Juan",
    "edad": 18,
    "curso": "Python"
}

for clave, valor in estudiante.items():
    print(clave, ":", valor)


# EJERCICIO 8
print("\n----- EJERCICIO 8 -----")

numeros = [10, 20, 30, 40, 50]
dobles = []

for n in numeros:
    dobles.append(n * 2)

print(dobles)


# EJERCICIO 9
print("\n----- EJERCICIO 9 -----")

numeros = list(range(1, 21))

for n in numeros:
    if n % 2 != 0:
        print(n)


# EJERCICIO 10
print("\n----- EJERCICIO 10 -----")

def factorial(n):
    resultado = 1
    for i in range(1, n+1):
        resultado *= i
    return resultado

print(factorial(5))